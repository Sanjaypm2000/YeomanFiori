sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("anubhav.app.controller.App",{})});
//# sourceMappingURL=App.controller.js.map